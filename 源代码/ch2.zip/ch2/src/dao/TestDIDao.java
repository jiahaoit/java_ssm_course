package dao;
public interface TestDIDao {
	public void sayHello();
}
