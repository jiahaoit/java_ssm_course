package dynamic.cglib;
public class TestDao {
	public void save() {
		System.out.println("����");
	}
	public void modify() {
		System.out.println("�޸�");
	}
	public void delete() {
		System.out.println("ɾ��");
	}
}
