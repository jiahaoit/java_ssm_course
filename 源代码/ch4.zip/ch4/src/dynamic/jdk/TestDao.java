package dynamic.jdk;
public interface TestDao {
	public void save();
	public void modify();
	public void delete();
}
