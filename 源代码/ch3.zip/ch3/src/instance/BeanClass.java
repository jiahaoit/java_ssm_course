package instance;
public class BeanClass {	
	public String message;
	public BeanClass() {
		message = "���췽��ʵ����Bean";
	}
	public BeanClass(String s) {
		message = s;
	}
}
